#!/bin/sh
sudo apt install python3-pip
pip install -r requirements.txt
sudo python3 setup.py install
