from setuptools import setup

setup(
    name='lab3',
    version='0.1',
    description='lab № 3',
    author='Maksina Elizaveta',
    packages=['lab3'],
    scripts = ['runlab3.py'],
)